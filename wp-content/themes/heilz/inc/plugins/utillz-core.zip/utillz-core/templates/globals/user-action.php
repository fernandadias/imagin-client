<?php

defined('ABSPATH') || exit;

?>

<div class="ulz-user-action">
    <a href="<?php echo esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ); ?>">
        <?php if( is_user_logged_in() ): ?>
            <span class="ulz-user-name ulz-ellipsis">
                <?php
                    $user = new \UtillzCore\Inc\Src\User();
                    $user_data = get_userdata( $user->id );
                    echo esc_html( $user_data->display_name );
                ?>
            </span>
            <!-- <span class="ulz-avatar">
                <i class="fas fa-user"></i>
            </span> -->
        <?php else: ?>
            <?php esc_html_e( 'Sign In', 'utillz-core' ); ?>
        <?php endif; ?>
    </a>
</div>