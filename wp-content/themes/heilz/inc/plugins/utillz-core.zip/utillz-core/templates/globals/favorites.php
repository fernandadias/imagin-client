<?php

defined('ABSPATH') || exit;

?>

<div class="ulz-favorites">
    <a href="#" class="ulz-favorites-icon" data-modal="favorites">
        <i class="far fa-heart"></i>
    </a>
</div>
