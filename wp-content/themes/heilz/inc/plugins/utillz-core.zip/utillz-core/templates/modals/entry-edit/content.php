<div class="ulz-modal ulz-modal-entry-edit" data-id="entry-edit">
    <?php Ucore()->the_template('modals/close'); ?>
    <div class="ulz-modal-heading">
        <h4 class="ulz--title"><?php esc_html_e( 'Entry', 'utillz-core' ); ?></h4>
    </div>
    <div class="ulz-modal-content">
        <?php Ucore()->the_template('modals/skeleton'); ?>
        <div class="ulz-modal-append"></div>
    </div>
</div>
