<?php

defined('ABSPATH') || exit;

global $ulz_listing;

?>

<div class="ulz-listing-action">
    <?php

        $action = \UtillzCore\Inc\Src\Listing\Action\Component::instance();
        $action->set_position('sidebar');

        foreach( Ucore()->json_decode( $ulz_listing->type->get('ulz_action_types') ) as $action_type_id => $action_type ) {
            $action->render( array_merge( (array) $action_type->fields, [
                'type' => $action_type->template->id,
            ]));
        }

    ?>
</div>
