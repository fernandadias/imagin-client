<?php

defined('ABSPATH') || exit;

?>

<div class="ulz--icon">
    <i class="material-icons">highlight_off</i>
    <p><?php esc_html_e( 'Please sign in to send message', 'utillz-core' ); ?></p>
</div>
