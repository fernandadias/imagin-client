<?php

use \UtillzCore\Inc\Src\Request\Request;
use \UtillzCore\Inc\Src\Listing\Listing;
use \UtillzCore\Inc\Src\Entry\Component;

defined('ABSPATH') || exit;

global $post, $ulz_modal_listing;

$request = Request::instance();
$component = Component::instance();

$post = get_post( (int) $request->get('id'), OBJECT );

if( ! $post ) {
    return;
}

$listing = new Listing( Ucore()->get('ulz_listing') );
if( $listing->id ) {
    $ulz_modal_listing = $listing;
}

?>

<?php Ucore()->the_template('modals/listing'); ?>

<?php

    $item = $component->render([
        'type' => Ucore()->get('ulz_entry_type'),
    ]);

?>
