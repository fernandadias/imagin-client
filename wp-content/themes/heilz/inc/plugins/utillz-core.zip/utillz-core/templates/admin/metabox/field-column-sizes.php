<?php

namespace UtillzCore\Templates\Admin\Metabox;

class Field_Column_Sizes {

    static public function get() {
        return [
            'fit' => esc_html__('Fit', 'utillz-core'),
            'auto' => esc_html__('Auto', 'utillz-core'),
            12 => esc_html__('100%', 'utillz-core'),
            9 => esc_html__('75%', 'utillz-core'),
            8 => esc_html__('66%', 'utillz-core'),
            6 => esc_html__('50%', 'utillz-core'),
            4 => esc_html__('33%', 'utillz-core'),
            3 => esc_html__('25%', 'utillz-core'),
        ];
    }
}
