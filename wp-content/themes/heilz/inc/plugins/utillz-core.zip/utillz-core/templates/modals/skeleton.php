<span class="ulz-skeleton">
    <span class="ulz--container">
        <span class="ulz--image -e">
            <i class="material-icons">image</i>
        </span>
        <span class="ulz--content">
            <span class="ulz--name x1 -e"></span>
            <span class="ulz--name x2 -e"></span>
            <span class="ulz--name x3 -e"></span>
        </span>
    </span>
</span>
