<?php

defined('ABSPATH') || exit;

?>

<div class="ulz-modal-container ulz-scrollbar">
    <div class="ulz--icon ulz-mt-3">
        <i class="material-icons">highlight_off</i>
        <p class="ulz-mb-3"><?php esc_html_e( 'You can\'t send messages to yourself', 'utillz-core' ); ?></p>
    </div>
</div>
