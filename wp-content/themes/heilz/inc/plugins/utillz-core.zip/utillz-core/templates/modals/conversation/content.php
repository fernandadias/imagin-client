<?php

defined('ABSPATH') || exit;

?>

<div class="ulz-modal ulz-modal-conversation" data-id="conversation">
    <?php Ucore()->the_template('modals/close'); ?>
    <div class="ulz-modal-heading">
        <h4 class="ulz--title"><?php esc_html_e( 'Send Message', 'utillz-core' ); ?></h4>
    </div>
    <div class="ulz-modal-content">
        <?php Ucore()->the_template('modals/skeleton'); ?>
        <div class="ulz-modal-append"></div>
    </div>
</div>
