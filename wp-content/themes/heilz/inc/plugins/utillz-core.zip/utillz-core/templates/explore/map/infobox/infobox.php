<?php

defined('ABSPATH') || exit;

global $ulz_listing;
$ulz_listing = new \UtillzCore\Inc\Src\Listing\Listing();

?>

<li data-id="<?php echo $ulz_listing->id; ?>">
    <div class="ulz-infobox">

        <div class="ulz-infobox-cover">

            <?php Ucore()->the_template('explore/listing/gallery'); ?>

            <?php Ucore()->the_template('explore/listing/priority'); ?>

            <?php Ucore()->the_template('explore/listing/badges'); ?>

        </div>

        <a class="ulz-infobox-content" href="<?php the_permalink(); ?>" <?php Ucore()->set_explore_open(); ?>>

            <?php Ucore()->the_template('explore/listing/heading'); ?>

            <?php Ucore()->the_template('explore/listing/details-bottom'); ?>

        </a>

    </div>
</li>
