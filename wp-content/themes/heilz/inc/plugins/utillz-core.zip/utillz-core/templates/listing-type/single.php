<?php

defined('ABSPATH') || exit;

?>

<div class="ulz-archive-mods">
    <?php

        $components = \UtillzCore\Inc\Src\Listing_Type\Component::instance();

        $listing_type = get_queried_object();
        $archive_modules = Ucore()->jsoning( 'ulz_archive_modules', $listing_type->ID );

        foreach( $archive_modules as $params ) {
            $components->render( $params );
        }

    ?>
</div>
