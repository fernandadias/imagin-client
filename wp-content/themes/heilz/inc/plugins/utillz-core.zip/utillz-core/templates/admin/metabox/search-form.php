<?php

use \UtillzCore\Inc\Src\Entry\Component as Entry;
use \UtillzCore\Templates\Admin\Metabox\Filters;

defined('ABSPATH') || exit;

$panel = \UtillzCore\Inc\Src\Admin\Panel::instance();
$panel->form->set( $panel->form::Storage_Meta );

?>

<div class="ulz-panel ulz-outer">
    <div class="ulz-section">
        <div class="ulz-form ulz-grid">
            <?php

                $panel->form->render([
                    'id' => 'listing_type',
                    'type' => 'select',
                    'name' => esc_html__( 'Select listing type (optional)', 'utillz-core' ),
                    'description' => esc_html__( 'Select listing type where to point the search results. If you leave this field empty, it will lead you to the global explore page', 'utillz-core' ),
                    'options' => 'listing-types'
                ]);

                $panel->form->render(
                    array_merge( apply_filters('utillz/modules/search-form/fields', Filters::get('search_fields') ) )
                );

            ?>
        </div>
    </div>
</div>
