<?php

defined('ABSPATH') || exit;

global $ulz_listing;

?>

<?php if( $ulz_listing->reviews->count ): ?>
    <div class="ulz-reviews-comments">

        <?php Ucore()->the_template('single/reviews/comments/list'); ?>

        <?php if( $ulz_listing->reviews->count > (int) $ulz_listing->type->get('ulz_reviews_per_page') ): ?>
            <div class="ulz-text-center">
                <a href="#" class="ulz-button ulz-mt-5" data-action="load-more-reviews">
                    <span><?php esc_html_e( 'Load More', 'utillz-core' ); ?></span>
                    <?php Ucore()->preloader(); ?>
                </a>
            </div>
        <?php endif; ?>

    </div>
<?php endif; ?>
