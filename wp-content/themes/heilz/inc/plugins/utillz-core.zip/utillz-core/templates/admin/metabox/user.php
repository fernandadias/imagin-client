<?php

defined('ABSPATH') || exit;

global $ulz_user;

$role = get_user_meta( $ulz_user->ID, 'ulz_role', true );

?>

<table class="form-table" role="presentation">
	<tbody>
    	<tr class="show-admin-bar user-admin-bar-front-wrap">
    		<th scope="row">
                <?php esc_html_e( 'User role', 'utillz-core' ); ?>
            </th>
    		<td>
				<select name="ulz_role" id="ulz_role">
					<option value="customer"<?php echo $role == 'customer' ? ' selected="selected"' : ''; ?>><?php esc_html_e( 'Customer', 'utillz-core' ); ?></option>
					<option value="business"<?php echo $role == 'business' ? ' selected="selected"' : ''; ?>><?php esc_html_e( 'Business', 'utillz-core' ); ?></option>
				</select>
    		</td>
    	</tr>
    </tbody>
</table>
