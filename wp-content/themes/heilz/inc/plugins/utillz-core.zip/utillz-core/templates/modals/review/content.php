<div class="ulz-modal ulz-modal-review-submit" data-id="review-submit">
    <?php Ucore()->the_template('modals/close'); ?>
    <div class="ulz-modal-heading ulz--border">
        <h4 class="ulz--title"><?php esc_html_e( 'Submit a Review', 'utillz-core' ); ?></h4>
    </div>
    <div class="ulz-modal-content">
        <?php Ucore()->the_template('modals/skeleton'); ?>
        <div class="ulz-modal-append"></div>
    </div>
</div>
