<?php

use \UtillzCore\Inc\Src\User;

defined('ABSPATH') || exit;

global $ulz_listing;

if( ! $ulz_listing->post ) {
    return;
}

$user = new User( $ulz_listing->post->post_author );

if( ! $user->id ) {
    return;
}

$userdata = get_userdata( $user->id );

?>

<a href="<?php the_permalink(); ?>" class="ulz-listing-author">
    <div class="ulz--image">
        <?php $user->the_avatar(); ?>
    </div>
    <div class="ulz--name">
        <?php echo esc_html( $userdata->display_name ); ?>
    </div>
</a>
