<?php

defined('ABSPATH') || exit;

global $ulz_listing;

?>

<div class="ulz-single-heading">
    <h1 class="ulz--title"><?php the_title(); ?></h1>
</div>
