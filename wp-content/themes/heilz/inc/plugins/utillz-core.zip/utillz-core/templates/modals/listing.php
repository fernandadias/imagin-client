<?php

defined('ABSPATH') || exit;

global $ulz_modal_listing;

?>

<?php if( $ulz_modal_listing ): ?>
    <?php $image = $ulz_modal_listing->get_first_from_gallery(); ?>
    <div class="ulz-modal-listing">
        <div class="ulz--inner">
            <div class="ulz--image">
                <?php if( $image ): ?>
                    <span class="ulz--img" style="background-image: url('<?php echo esc_url( $image ); ?>');"></span>
                <?php else: ?>
                    <?php echo Ucore()->dummy('place', 'material-icons'); ?>
                <?php endif; ?>
            </div>
            <div class="ulz--content">
                <h4 class="ulz--title"><?php echo esc_html( $ulz_modal_listing->post->post_title ); ?></h4>
            </div>
        </div>
    </div>
<?php endif; ?>
