<?php

$pre_defined = Ucore()->get_pre_defined();

?>

<div class="ulz-outer">
    <div class="ulz-modal ulz-modal-field-icon" data-id="field-icon">
        <?php Ucore()->the_template('modals/close'); ?>
        <div class="ulz-modal-heading ulz--border">
            <h4 class="ulz--title"><?php esc_html_e( 'Icon Selection', 'utillz-core' ); ?></h4>
        </div>
        <div class="ulz-modal-content">
            <?php Ucore()->the_template('modals/skeleton'); ?>
            <div class="ulz-modal-append"></div>
        </div>
    </div>
</div>
