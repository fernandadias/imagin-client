<?php get_header(); ?>

<div class="ulz-container">
	<?php the_content(); ?>
</div>

<?php get_footer();
