<?php

defined('ABSPATH') || exit;

use \UtillzCore\Inc\Src\Form\Component as Form;

$form = new Form( Form::Storage_Term );

?>

<div class="ulz-panel ulz-outer" style="max-width: 95%;">
    <div class="ulz-section">
        <div class="ulz-form ulz-grid">
            <?php

                $form->render([
                    'type' => 'icon',
                    'id' => 'icon',
                    'name' => esc_html__('Icon', 'utillz-core'),
                    'class' => ['ulz-mb-0']
                ]);

            ?>
        </div>
    </div>
</div>
