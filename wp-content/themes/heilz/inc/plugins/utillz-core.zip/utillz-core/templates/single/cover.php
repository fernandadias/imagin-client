<?php

defined('ABSPATH') || exit;

global $ulz_listing;

$gallery = $ulz_listing->get_gallery([
    'ulz_gallery_large',
    'ulz_gallery_preview'
]);

$cover_type = $ulz_listing->type->get('ulz_single_cover_type');

?>

<?php if( $cover_type == 'full-cover' ): ?>
    <?php if( $gallery ): ?>
        <div class="ulz-cover">
            <div class="ulz-gallery-rail">
                <div class="ulz-gallery">
                    <?php foreach( $gallery as $key => $image ): ?>
                        <img src="<?php echo esc_url( $image['ulz_gallery_large'] ); ?>" alt="">
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>
