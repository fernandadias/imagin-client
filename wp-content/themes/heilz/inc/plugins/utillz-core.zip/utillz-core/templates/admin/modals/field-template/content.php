<div class="ulz-modal ulz-modal-field-template" data-id="field-template">
    <?php Ucore()->the_template('modals/close'); ?>
    <div class="ulz-modal-heading ulz--border">
        <h4 class="ulz--title"><?php esc_html_e( 'Template Fields', 'utillz-core' ); ?></h4>
    </div>
    <div class="ulz-modal-content">
        <div class="ulz-modal-append">
            <div class="ulz-modal-container">
                <h3><?php esc_html_e( 'Pre-defined field', 'utillz-core' ); ?></h3>
                <p><?php esc_html_e( 'Here is the full list of pre-defined fields that you can use in your templates.', 'utillz-core' ); ?>:</p>

                <p><strong><?php esc_html_e( 'Receiver', 'utillz-core' ); ?></strong></p>
                <p>
                    <code>{user_id}</code>
                    <code>{user_first_name}</code>
                    <code>{user_last_name}</code>
                    <code>{user_display_name}</code>
                    <code>{user_email}</code>
                    <code>{user_billing_phone}</code>
                </p>

                <p><strong><?php esc_html_e( 'Sender', 'utillz-core' ); ?></strong></p>
                <p>
                    <code>{from_user_id}</code>
                    <code>{from_user_first_name}</code>
                    <code>{from_user_last_name}</code>
                    <code>{from_user_display_name}</code>
                    <code>{from_user_email}</code>
                    <code>{from_user_billing_phone}</code>
                </p>

                <p><strong><?php esc_html_e( 'Listing', 'utillz-core' ); ?></strong></p>
                <p>
                    <code>{listing_id}</code>
                    <code>{listing_name}</code>
                    <code>{listing_url}</code>
                </p>

                <h3><?php esc_html_e( 'Custom meta field', 'utillz-core' ); ?></h3>
                <p><u><?php esc_html_e( 'Advanced', 'utillz-core' ); ?></u>: <?php esc_html_e( 'you can also get some custom meta fields from your listings. Here is an example how to get meta field with key `my_custom_meta_field`', 'utillz-core' ); ?>: </p>
                <p><code>{listing:my_custom_meta_field}</code></p>
            </div>
        </div>
        <?php Ucore()->preloader(); ?>
    </div>
</div>
