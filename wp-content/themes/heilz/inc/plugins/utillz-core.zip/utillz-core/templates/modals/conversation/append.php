<?php

defined('ABSPATH') || exit;

use \UtillzCore\Inc\Src\User;
use \UtillzCore\Inc\Src\Listing\Conversation;

global $ulz_conversation;

if( ! is_user_logged_in() ) {

    // not logged in
    Ucore()->the_template('modals/conversation/notice-signin');

}else{

    if( ! $ulz_conversation->is_own() ) {

        global $ulz_modal_listing;
        if( isset( $ulz_conversation->listing->id ) && ! is_null( $ulz_conversation->listing->id ) ) {
            $ulz_modal_listing = $ulz_conversation->listing;
        }

        // listing
        Ucore()->the_template('modals/listing');

        // messages
        Ucore()->the_template('modals/conversation/messages');

    }else{

        // owned listing
        Ucore()->the_template('modals/conversation/notice-owner');

    }
}

// preloader
Ucore()->the_template('globals/preloader');
