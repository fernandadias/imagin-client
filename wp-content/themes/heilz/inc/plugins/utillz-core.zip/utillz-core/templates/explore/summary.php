<?php

defined('ABSPATH') || exit;

global $ulz_explore;

$from = ( $ulz_explore->query()->page - 1 ) * $ulz_explore->query()->posts_per_page + 1;
$to = $from + $ulz_explore->query()->posts_per_page - 1;

?>

<div class="ulz-summary ulz-text-center">
    <p>
        <?php echo sprintf(
            esc_html__( '%s - %s of %s listings. ', 'utillz-core' ),
            $from,
            $to > $ulz_explore->query()->posts->found_posts ? $ulz_explore->query()->posts->found_posts : $to,
            $ulz_explore->query()->posts->found_posts
        ); ?>
    </p>
</div>
