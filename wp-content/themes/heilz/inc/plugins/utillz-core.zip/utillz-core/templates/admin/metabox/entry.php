<?php

use \UtillzCore\Inc\Src\Entry\Component as Entry;

defined('ABSPATH') || exit;

$panel = \UtillzCore\Inc\Src\Admin\Panel::instance();
$panel->form->set( $panel->form::Storage_Meta );
$entry = Entry::instance();

?>

<div class="ulz-panel ulz-outer">
    <div class="ulz-section">

        <?php

            $entry_type = Ucore()->get('ulz_entry_type');

            if( $entry_type ) {
                $entry->render([
                    'type' => $entry_type,
                ]);
            }

        ?>

    </div>
</div>
