<?php

use \UtillzCore\Inc\Src\Wallet;

defined('ABSPATH') || exit;

$wallet = new Wallet();

?>

<div class="ulz-wallet-balance">
    <?php echo Ucore()->format_price( $wallet->get_balance() ); ?>
</div>