<a href="#" class="ulz-close" data-action="modal-close">
    <i class="fas fa-times"></i>
</a>
