<?php

defined('ABSPATH') || exit;

global $ulz_listing;

?>

<?php $details = $ulz_listing->get_details('ulz_display_listing_bottom'); ?>
<?php if( $details ): ?>
    <div class="ulz-listing-bottom">
        <ul>
            <?php foreach( $details as $detail ): ?>
                <li>
                    <span>
                        <?php if( $detail->icon ): ?>
                            <i class="<?php echo esc_html( $detail->icon ); ?>"></i>
                        <?php endif; ?>
                        <?php echo wp_kses( $detail->content, Ucore()->allowed_html() ); ?>
                    </span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
