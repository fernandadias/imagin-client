<div class="ulz-user-avatar">
    <div class="ulz-user-avatar-img">
        <i class="fas fa-user"></i>
    </div>
</div>