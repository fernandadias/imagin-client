<?php

defined('ABSPATH') || exit;

global $ulz_explore;

$ulz_search_form_id = $ulz_explore->type ? $ulz_explore->type->get('ulz_search_form') : get_option('ulz_global_search_form');

?>

<div class="ulz-explore" id="ulz-explore">
    <?php /*if( substr( $ulz_explore->get_display_type(), 0, 3 ) == 'map' ): ?>
        <?php Ucore()->the_template('explore/map/map'); ?>
    <?php endif;*/ ?>
    <?php if( $ulz_search_form_id ): ?>
        <div class="ulz-explore-sidebar">
            <?php Ucore()->the_template('explore/filters'); ?>
        </div>
    <?php endif; ?>
    <div class="ulz-explore-content">
        <?php Ucore()->the_template('explore/listings'); ?>
    </div>
</div>
