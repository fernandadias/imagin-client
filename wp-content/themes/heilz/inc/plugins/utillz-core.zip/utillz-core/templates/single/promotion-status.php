<?php

defined('ABSPATH') || exit;

global $ulz_listing;

?>

<?php if( $ulz_listing->is_owner() ): ?>
    <?php $promoted_expiration = (int) Ucore()->get( 'ulz_promotion_expires' ); ?>
    <?php if( $promoted_expiration && $promoted_expiration > time() ): ?>
        <div class="ulz--listing-promoted">
            <i class="fas fa-fire-alt ulz-mr-1"></i>
            <span>
                <?php
                    echo sprintf(
                        __( 'Promoted, expires: %s', 'utillz-core' ),
                        date_i18n(
                            get_option('date_format'),
                            $promoted_expiration
                        )
                    );
                ?>
            </span>
        </div>
    <?php endif; ?>
<?php endif; ?>
