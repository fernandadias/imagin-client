<?php

defined('ABSPATH') || exit;

use \UtillzCore\Inc\Src\Form\Component as Form;

$form = new Form( Form::Storage_Term );

?>

<label><?php esc_html_e('Term Options', 'utillz-core') ?></label>

<div class="ulz-panel ulz-outer ulz-mt-1 ulz-mb-3" style="max-width: 95%;">
    <div class="ulz-section">
        <div class="ulz-form ulz-grid">
            <?php

                $form->render([
                    'type' => 'icon',
                    'id' => 'icon',
                    'name' => esc_html__('Icon', 'utillz-core'),
                    'class' => ['ulz-mb-0']
                ]);

            ?>
        </div>
    </div>
</div>
