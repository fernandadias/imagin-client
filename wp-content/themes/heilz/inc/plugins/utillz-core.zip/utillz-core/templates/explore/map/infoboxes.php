<?php

defined('ABSPATH') || exit;

global $ulz_explore;

?>

<ul class="ulz-dynamic ulz-none" data-dynamic="infoboxes">
    <?php // if( $ulz_explore->type ) : ?>
        <?php if( $ulz_explore->query()->posts->have_posts() ) : ?>
            <?php while( $ulz_explore->query()->posts->have_posts() ) : $ulz_explore->query()->posts->the_post(); ?>
                <?php $location = get_post_meta( get_the_ID(), 'ulz_location', false ); ?>
                <?php if( $location ): ?>
                    <?php Ucore()->the_template('explore/map/infobox/infobox'); ?>
                <?php endif; ?>
            <?php endwhile; ?>
        <?php endif; ?>
    <?php // endif; ?>
</ul>
