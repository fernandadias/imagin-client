<?php

use \UtillzCore\Inc\Src\Entry\Component as Entry;

defined('ABSPATH') || exit;

$entry = Entry::instance();

?>

<div class="ulz-outer">
    <div class="ulz-listing-edit">
        <?php

            $entry->render([
                'type' => Ucore()->get('ulz_entry_type'),
            ]);

        ?>
    </div>
</div>