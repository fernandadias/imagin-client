<?php

namespace UtillzCore\Inc\Src\Admin;

use \UtillzCore\Inc\Src\Form\Component as Form;

class Panel {

    use \UtillzCore\Inc\Src\Traits\Singleton;

    function __construct() {

        $this->form = new Form();

        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
        add_action( 'admin_footer', [ $this, 'templates' ] );

    }

    public function enqueue_scripts() {

        wp_enqueue_script('utillz-panel');
        wp_enqueue_style('utillz-panel');

    }

    public function templates() {

        Ucore()->the_template('admin/modals/field-id/content');
        Ucore()->the_template('admin/modals/field-icon/content');

        echo '<span class="ulz-overlay" data-action="modal-close"></span>';

    }

}
