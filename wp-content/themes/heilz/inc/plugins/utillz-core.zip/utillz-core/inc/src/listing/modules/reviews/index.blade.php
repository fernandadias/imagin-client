<div class="ulz-mod-listing ulz-mod-listing-reviews" data-type="reviews">
    @if( ! empty( $name ) )
        <h4>{{ $name }}</h4>
    @endif
    {{ Ucore()->the_template('single/reviews/reviews') }}
</div>
