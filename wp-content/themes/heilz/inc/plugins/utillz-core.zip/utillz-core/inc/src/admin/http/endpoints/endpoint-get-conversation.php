<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

use \UtillzCore\Inc\Src\Request\Request;
use \UtillzCore\Inc\Src\Listing\Conversation;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Get_Conversation extends Endpoint {

	public $action = 'utillz-get-conversation';

    public function action() {

		global $ulz_conversation;

		$request = Request::instance();
		$ulz_conversation = new Conversation( $request->get('id') );
		$ulz_conversation->mark_as_read();

		wp_send_json([
			'success' => true,
			'count' => $ulz_conversation->count_messages(),
			'html' => Ucore()->get_template('modals/conversation/append')
		]);

	}

}
