<?php

namespace UtillzCore\Inc\Src\Listing\Action\Modules\Contact;

use \UtillzCore\Inc\Src\User;
use \UtillzCore\Inc\Src\Listing\Action\Modules\Module;

class Contact extends Module {

    public function controller() {

        return array_merge( (array) $this->props, [
            'component' => $this->component,
            'listing_id' => get_the_ID(),
            'strings' => (object) [
                'send_message' => esc_html__('Send message', 'utillz-core'),
            ]
        ]);

    }

}
