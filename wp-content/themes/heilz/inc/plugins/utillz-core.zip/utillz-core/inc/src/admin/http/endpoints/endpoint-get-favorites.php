<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

use \UtillzCore\Inc\Src\Request\Request;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Get_Favorites extends Endpoint {

	public $action = 'utillz-get-favorites';

    public function action() {

		wp_send_json([
			'success' => true,
			'html' => Ucore()->get_template('modals/favorites/append')
		]);

	}

}
