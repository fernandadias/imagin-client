<?php

namespace UtillzCore\Inc\Src\Form\Modules\Heading;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Heading extends Module {

    // ..

}
