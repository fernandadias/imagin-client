<?php

namespace UtillzCore\Inc\Src\Listing\Modules;

use UtillzCore\Inc\Extensions\Component\Module as Main_Module;
use UtillzCore\Inc\Src\Listing\Init;

abstract class Module extends Main_Module {

    public function get_engine() {
        return Init::instance()->engine();
    }

    public function get() {
        $this->before_get();
        return $this->template();
    }

    // public function wrapper() {
    //     return '<div class="ulz-mod-listing ulz-mod-listing-%1$s" data-type="%1$s">%2$s</div>';
    // }

}
