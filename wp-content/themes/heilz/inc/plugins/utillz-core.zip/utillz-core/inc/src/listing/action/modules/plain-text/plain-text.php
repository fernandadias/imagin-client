<?php

namespace UtillzCore\Inc\Src\Listing\Action\Modules\Plain_Text;

use \UtillzCore\Inc\Src\User;
use \UtillzCore\Inc\Src\Listing\Action\Modules\Module;
use \UtillzCore\Inc\Src\Listing\Listing;

class Plain_Text extends Module {

    // ..

}
