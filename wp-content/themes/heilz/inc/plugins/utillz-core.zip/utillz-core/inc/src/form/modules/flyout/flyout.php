<?php

namespace UtillzCore\Inc\Src\Form\Modules\Flyout;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Flyout extends Module {

    public function before_construct() {
        $this->defaults += [
            'label' => esc_html__('Select', 'utillz-core'),
            'strings' => (object) [
                'close' => esc_html__('Close', 'utillz-core')
            ]
        ];

    }

}
