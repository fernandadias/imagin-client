<?php

namespace UtillzCore\Inc\Src\Form\Modules\Text;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Text extends Module {

    public function before_construct() {

        $this->defaults += [
            'autocomplete' => '',
        ];

    }

}
