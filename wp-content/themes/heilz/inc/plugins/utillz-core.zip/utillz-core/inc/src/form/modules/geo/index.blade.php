@include('label.index')

<div class="ulz-geo-field">

    <input
        type="text"
        name="ulz_geo"
        value="{{ $value }}"
        placeholder="{{ $placeholder }}"
        class="{{ $html->class }}"
        @if( $html->id )id="{{ $html->id }}"@endif>

    <a href="#" class="ulz-geo-get">
        <i class="material-icons">gps_fixed</i>
    </a>

</div>

<input type="hidden" name="ulz_geo_n" value="{{ $geo_n }}">
<input type="hidden" name="ulz_geo_e" value="{{ $geo_e }}">
<input type="hidden" name="ulz_geo_s" value="{{ $geo_s }}">
<input type="hidden" name="ulz_geo_w" value="{{ $geo_w }}">
