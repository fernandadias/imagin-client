@include('label.index')

<textarea
    type="text"
    name="{{ $id }}"
    placeholder="{{ $placeholder }}"
    {{ $disabled ? 'disabled' : '' }}>{!! $value !!}</textarea>
