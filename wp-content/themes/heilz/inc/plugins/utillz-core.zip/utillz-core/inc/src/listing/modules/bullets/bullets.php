<?php

namespace UtillzCore\Inc\Src\Listing\Modules\Bullets;

use \UtillzCore\Inc\Src\Listing\Modules\Module;

class Bullets extends Module {

    // ..

}
