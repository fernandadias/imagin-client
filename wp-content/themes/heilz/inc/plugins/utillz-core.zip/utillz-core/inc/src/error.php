<?php

namespace UtillzCore\Inc\Src;

class Error {

    public $errors = [];

    function __construct( $error ) {
        $this->errors[] = $error;
    }

    public function get_error() {
        return sprintf( '<div class="ulz-notice ulz-notice-alert"><p>%s</p></div>', implode( '</li><li>', $this->errors ) );
    }

}
