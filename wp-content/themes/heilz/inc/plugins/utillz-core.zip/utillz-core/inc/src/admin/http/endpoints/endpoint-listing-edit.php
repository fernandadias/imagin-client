<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Listing_Edit extends Endpoint {

	public $action = 'utillz-listing-edit';

    public function action() {

		wp_send_json([
			'success' => true,
			'html' => Ucore()->get_template('modals/listing-edit/append')
		]);

	}

}
