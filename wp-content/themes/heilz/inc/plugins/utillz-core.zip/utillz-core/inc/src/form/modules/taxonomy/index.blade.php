@if( empty( $props['options'] ) )
    @include('label.index')
    <p class="ulz-mb-0">{{ $strings->not_found }}</p>
@else
    {{ $component->render( array_merge( $props, [
        'type' => $props['display'],
    ])) }}
@endif
