<?php

namespace UtillzCore\Inc\Src\Listing\Action\Modules\Report;

use \UtillzCore\Inc\Src\Listing\Action\Modules\Module;

class Report extends Module {

    public function controller() {

        return array_merge( (array) $this->props, [
            'strings' => (object) [
                'report' => esc_html__('Report this listing', 'utillz-core'),
            ]
        ]);

    }

}
