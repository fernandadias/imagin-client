<?php

namespace UtillzCore\Inc\Src\Listing\Modules\Menu;

use \UtillzCore\Inc\Src\Listing\Modules\Module;

class Menu extends Module {

    public function controller() {

        global $ulz_listing;

        // d( Ucore()->json_decode( $ulz_listing->get('ulz_menu') ) );

        return array_merge( (array) $this->props, [
            'items' => Ucore()->json_decode( $ulz_listing->get('ulz_menu') )
            // 'id' => $this->props->id,
            // 'name' => $this->props->name,
            // 'content' => Ucore()->get( $this->props->id ),
        ]);

    }

}
