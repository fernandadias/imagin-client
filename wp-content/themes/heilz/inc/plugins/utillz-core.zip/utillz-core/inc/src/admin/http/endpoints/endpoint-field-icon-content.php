<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Field_Icon_Content extends Endpoint {

	public $action = 'utillz-field-icon-content';

    public function action() {

		ob_start();
		include UTILLZ_CORE_PATH . 'inc/src/form/modules/icon/content.php';

		wp_send_json([
			'success' => true,
			'html' => ob_get_clean()
		]);

	}

}
