@php
    $component->render( array_merge( $props, [
        'type' => 'checklist',
        'columns' => 3,
        'allow_empty' => true,
    ]));
@endphp
