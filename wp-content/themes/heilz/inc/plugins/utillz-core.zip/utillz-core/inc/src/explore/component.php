<?php

namespace UtillzCore\Inc\Src\Explore;

use \UtillzCore\Inc\Src\Traits\Singleton;
use \UtillzCore\Inc\Extensions\Component\Component as Main_Component;

class Component extends Main_Component {

    use Singleton;

}
