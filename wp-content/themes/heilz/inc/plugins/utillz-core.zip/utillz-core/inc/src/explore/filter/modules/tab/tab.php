<?php

namespace UtillzCore\Inc\Src\Explore\Filter\Modules\Tab;

use \UtillzCore\Inc\Src\Explore\Filter\Modules\Module;
use \UtillzCore\Inc\Src\Explore\Filter\Comparison;

class Tab extends Module {

    public function controller() {

        return array_merge( (array) $this->props, [
            'component' => $this->component,
            'strings' => (object) [
                'close' => esc_html__( 'Close', 'utillz-core' ),
                'tab_empty' => esc_html__( 'No fields were found', 'utillz-core' ),
            ]
        ]);

    }

    public function query() {

        return [];

    }

}
