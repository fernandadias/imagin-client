@include('label.index')

<div class="ulz-radio-images ulz-flex ulz-flex-wrap">
    @foreach( $options as $option_key => $option )
        @if( isset( $option['image'] ) && isset( $option['label'] ) )
            <label class="ulz-radio-image-fieldset">
                <input type="radio" name="{{ $id }}" value="{{ $option_key }}" {{ $option_key == $value ? 'checked' : '' }}>
                <div class='ulz-radio-image ulz-no-select'>
                    @if( substr( $option['image'], 0, 1 ) == '<' )
                        {!! $option['image'] !!}
                    @else
                        <img class="ulz--label" src="{{ $option['image'] }}" alt="">
                    @endif
                    <span>{{ $option['label'] }}</span>
                </div>
            </label>
    @endif
    @endforeach
</div>
