<?php

namespace UtillzCore\Inc\Src\Form\Modules\Toggle;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Toggle extends Module {

    public function initial() {
        $this->html = [
            'text' => 'Yes'
        ];
    }

}
