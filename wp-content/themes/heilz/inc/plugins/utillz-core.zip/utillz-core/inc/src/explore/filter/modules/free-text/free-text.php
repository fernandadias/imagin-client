<?php

namespace UtillzCore\Inc\Src\Explore\Filter\Modules\Free_Text;

use \UtillzCore\Inc\Src\Explore\Filter\Modules\Module;
use \UtillzCore\Inc\Src\Explore\Filter\Comparison;

class Free_Text extends Module {

    // do not compare
    public function query() {
        return;
    }

    public function get() {

        $this->before_get();

        if( ! empty( $this->props->content ) ) {
            return sprintf( $this->wrapper(), $this->props->type, '<div class="ulz-form-group ulz-field ulz-col-12 ulz-field-ready">' . do_shortcode( wpautop( html_entity_decode( $this->props->content ) ) ) . '</div>' );
        }

    }

}
