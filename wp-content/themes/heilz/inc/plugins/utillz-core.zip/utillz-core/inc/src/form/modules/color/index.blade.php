@include('label.index')

<div class="ulz-color">
    <i class="ulz--preview"></i>
    <input type="text" name="{{ $id }}" value="{{ $value }}" placeholder="{{ $placeholder }}">
</div>
