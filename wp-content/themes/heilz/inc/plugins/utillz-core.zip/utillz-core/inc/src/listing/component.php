<?php

namespace UtillzCore\Inc\Src\Listing;

use \UtillzCore\Inc\Src\Traits\Singleton;
use \UtillzCore\Inc\Extensions\Component\Component as Main_Component;
use \UtillzCore\Inc\Src\Form\Component as Form;

class Component extends Main_Component {

    use Singleton;

    function __construct() {

        $this->form = new Form( Form::Storage_Request );

    }

}
