<div class="ulz-form-group ulz-col-12">

    <div class="ulz-filter-heading">
        @if( $name )
            <h5 class="ulz--heading">{{ $name }}</h5>
            @if( isset( $description ) && ! empty( $description ) )
                <p>{{ $description }}</p>
            @endif
        @endif
    </div>

</div>
