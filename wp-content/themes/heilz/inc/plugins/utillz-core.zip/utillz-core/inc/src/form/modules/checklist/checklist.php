<?php

namespace UtillzCore\Inc\Src\Form\Modules\Checklist;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Checklist extends Module {

    public function before_construct() {
        $this->defaults += [
            'options' => [],
            'columns' => 1,
        ];
    }

    public function initial() {
        if( ! $this->props->value ) {
            $this->props->value = [];
        }
    }

    public function after_build() {

        $this->props->single = false;
        $this->props->options = $this->component->extract_options( $this->props );

    }

}
