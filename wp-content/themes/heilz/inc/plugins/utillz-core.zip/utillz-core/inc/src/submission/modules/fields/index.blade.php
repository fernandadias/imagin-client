<h4 class="ulz--title">{{ $title }}</h4>

@if( $fields )
    <form>
        <div class="ulz-grid">
            @foreach( $fields as $item )
                @if( $item->fields->is_submit_form )
                    {{ $form->render( Ucore()->prefix_item( $item ) ) }}
                @endif
            @endforeach
        </div>
    </form>
@else
    <div class="ulz-submission-error ulz-block">
        <div class="ulz--error">
            <div class="ulz--content">
                {{ $strings->not_found }}
            </div>
        </div>
    </div>
@endif