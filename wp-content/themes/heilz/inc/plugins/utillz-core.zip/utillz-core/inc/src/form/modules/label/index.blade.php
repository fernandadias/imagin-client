@if( ( isset( $name ) && ! empty( $name ) ) || ( isset( $description ) && ! empty( $description ) ) )
    <div class="ulz-heading">
        @if( $name )
            <label class="@if( ! empty( $description ) ) mb-0 @endif">
                {!! $name !!}
                @if( $required )
                    <i class="ulz-required"></i>
                @endif
            </label>
        @endif
        @if( $description )
            <p>{!! nl2br( wp_kses_post( html_entity_decode( $description ) ) ) !!}</p>
        @endif
    </div>
@endif
