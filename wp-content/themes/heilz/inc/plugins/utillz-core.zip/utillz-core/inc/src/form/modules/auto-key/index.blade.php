<input
    type="hidden"
    name="{{ $id }}"
    value="{{ $value }}"
    data-char-type="{{ $char_type }}"
    data-char-length="{{ $char_length }}">
