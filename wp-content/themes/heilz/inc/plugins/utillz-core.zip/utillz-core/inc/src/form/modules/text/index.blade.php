@include('label.index')

<input

    type="text"
    name="{{ $id }}"
    value="{{ $value }}"
    placeholder="{{ $placeholder }}"
    class="{{ $html->class }}"
    @if( $autocomplete == 'off' ) autocomplete="off" @endif
    @if( $html->id )id="{{ $html->id }}"@endif

    {{ $v_model ? "v-model={$v_model}" : '' }}
    {{ $disabled ? 'disabled' : '' }}
    {{ ( isset( $readonly ) && $readonly == true ) ? 'form="fake-form-readonly"' : '' }}>
