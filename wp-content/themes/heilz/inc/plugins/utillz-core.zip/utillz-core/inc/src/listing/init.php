<?php

namespace UtillzCore\Inc\Src\Listing;

use \UtillzCore\Inc\Extensions\Component\Init as Main_Init;
use \UtillzCore\Inc\Src\Traits\Singleton;
use \UtillzCore\Inc\Src\Listing\Listing;
use \UtillzCore\Inc\Src\Listing\iCal;
use \UtillzCore\Inc\Src\Request\Request;

class Init extends Main_Init {

    use Singleton;

    function __construct() {

        parent::__construct();

        // single listing, main query
        if( is_single() && is_main_query() ) {

            // get the listing
            // $listing = new Listing( get_the_ID() );
            // do something on listing page ..

        }
    }

    public function enqueue_scripts() {

        wp_enqueue_script('utillz-listing');
        wp_enqueue_style('utillz-listing');

    }

}
