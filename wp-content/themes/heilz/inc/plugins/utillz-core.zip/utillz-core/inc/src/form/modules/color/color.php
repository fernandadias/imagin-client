<?php

namespace UtillzCore\Inc\Src\Form\Modules\Color;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Color extends Module {

    // ..

}
