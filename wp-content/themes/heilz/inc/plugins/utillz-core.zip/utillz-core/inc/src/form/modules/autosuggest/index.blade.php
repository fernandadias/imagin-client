@include('label.index')

<div class="ulz-autosuggest<?php if( $value ) { echo ' ulz--selected'; } ?>">

    <div class="ulz--input">
        {{ Ucore()->preloader() }}
        <input
            class="ulz--label ulz-transition"
            type="text"
            placeholder="{{ $placeholder }}"
            value="{{ $term_name ? $term_name : $value }}"
            autocomplete="off">
        <input class="ulz--value" name="{{ $id }}" type="hidden" value="{{ $value }}" data-name="{{ $real_id }}">
        <a href="#" class="ulz--clear">
            <i class="material-icons">cancel</i>
        </a>
    </div>

    <div class="ulz--results ulz-is-empty">
        <ul class="ulz-listed">
            <!-- autosuggest rows -->
        </ul>
    </div>

</div>
