<?php

namespace UtillzCore\Inc\Src\Explore\Filter\Modules\Tab_Break;

use \UtillzCore\Inc\Src\Explore\Filter\Modules\Module;
use \UtillzCore\Inc\Src\Explore\Filter\Comparison;

class Tab_Break extends Module {

    public function query() {
        return [];
    }

    public function get() {}

}
