<div class="ulz-step-publish ulz-text-center">
    <div>
        <span class="ulz--icon"><i class="fas fa-paper-plane"></i></span>
        <h4 class="ulz--title">{{ $strings->about_publish }}</h4>
        <p>{{ $strings->confirm }}</p>
    </div>
</div>
