<?php

namespace UtillzCore\Inc\Src\Form\Modules\Checkbox;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Checkbox extends Module {

    public function initial() {
        $this->html = [
            'text' => esc_html__( 'Yes', 'utillz-core' )
        ];
    }

}
