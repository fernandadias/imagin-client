<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

use \UtillzCore\Inc\Src\Request\Request;
use \UtillzCore\Inc\Src\Form\Modules\Icon\Icon;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Field_Icon_Change_Set extends Endpoint {

	public $action = 'utillz-field-icon-change-set';

    public function action() {

		$request = Request::instance();

		wp_send_json([
			'success' => true,
			'html' => implode( '', Icon::get_icons( $request->get('set'), $request->get('icon') ) )
		]);

	}

}
