<?php

namespace UtillzCore\Inc\Src\Form\Modules\Separator;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Separator extends Module {

    // ..

}
