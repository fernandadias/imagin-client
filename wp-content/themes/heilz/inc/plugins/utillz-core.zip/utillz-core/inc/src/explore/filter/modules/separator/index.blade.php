<div class="ulz-form-group ulz-col-12">
    <span class="ulz-filter-separator"></span>
</div>
