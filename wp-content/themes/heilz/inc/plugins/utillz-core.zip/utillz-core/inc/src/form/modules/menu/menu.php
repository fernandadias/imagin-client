<?php

namespace UtillzCore\Inc\Src\Form\Modules\Menu;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Menu extends Module {

    public function controller() {

        return [
            'props' => (array) $this->props,
            'component' => $this->component,
            'strings' => (object) [
                'add_section' => esc_html__('Add Section', 'utillz-core'),
                'section' => esc_html__('Section', 'utillz-core'),
                'name' => esc_html__('Name', 'utillz-core'),
                'item' => esc_html__('Item', 'utillz-core'),
                'items' => esc_html__('Items', 'utillz-core'),
                'description' => esc_html__('Description', 'utillz-core'),
                'price' => esc_html__('Price', 'utillz-core'),
                'special' => esc_html__('How is this item special? (optional)', 'utillz-core'),
                'short_info' => esc_html__('Add some short information if you want to highlight the menu item', 'utillz-core'),
            ]
        ];

    }

}
