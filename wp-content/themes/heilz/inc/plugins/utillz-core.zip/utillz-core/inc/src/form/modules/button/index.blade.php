<a href="{{ $uri }}" class="ulz-button {{ $html->class }}" @if( $html->id ) id="{{ $html->id }}" @endif>
    <span>{{ $name }}</span>
    @if( $html->preloader )
        {{ Ucore()->the_template('globals/preloader') }}
    @endif
</a>
