<?php

namespace UtillzCore\Inc\Src\Form;

use \UtillzCore\Inc\Extensions\Component\Init as Main_Init;
use \UtillzCore\Inc\Src\Traits\Singleton;

class Init extends Main_Init {

    use Singleton;

    public function __call( $method, $arguments ) {
        throw new Exception("Method {$name} is not supported.");
    }

    public function enqueue_scripts() {

        wp_enqueue_script('utillz-form');
        wp_enqueue_style('utillz-form');

    }

}
