<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

use \UtillzCore\Inc\Src\Request\Request;
use \UtillzCore\Inc\Src\Listing\Listing;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Review_Get extends Endpoint {

	public $action = 'utillz-review-get';

    public function action() {

		$request = Request::instance();

		if( ! $request->has('listing_id') ) {
			return;
		}

		$listing = new Listing( $request->get('listing_id') );

		if( ! $listing->id ) {
			return;
		}

		wp_send_json([
			'success' => true,
			'html' => Ucore()->get_template('modals/review/append')
		]);

	}

}
