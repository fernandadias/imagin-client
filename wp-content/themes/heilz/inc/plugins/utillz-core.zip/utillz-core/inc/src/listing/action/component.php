<?php

namespace UtillzCore\Inc\Src\Listing\Action;

use \UtillzCore\Inc\Src\Traits\Singleton;
use \UtillzCore\Inc\Extensions\Component\Component as Main_Component;
use \UtillzCore\Inc\Src\Form\Component as Form;

class Component extends Main_Component {

    use Singleton;

    public $position;

    function __construct() {

        $this->form = new Form( Form::Storage_Field );

    }

    public function set_position( $position ) {
        $this->position = $position;
    }

    public function get_position() {
        return $this->position;
    }

    public function render( $props ) {

        $module = $this->create( $props );

        if( ! Ucore()->is_error( $module ) ) {
            echo $module->get();
        }else{
            echo $module->get_error();
        }

    }

}
