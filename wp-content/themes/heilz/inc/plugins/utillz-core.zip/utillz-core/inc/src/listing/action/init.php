<?php

namespace UtillzCore\Inc\Src\Listing\Action;

use \UtillzCore\Inc\Extensions\Component\Init as Main_Init;
use \UtillzCore\Inc\Src\Traits\Singleton;

class Init extends Main_Init {
    
    use Singleton;

}
