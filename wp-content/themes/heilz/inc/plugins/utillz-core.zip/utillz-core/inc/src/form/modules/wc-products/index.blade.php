@if( $props['options'] )
    {{ $component->render( array_merge( $props, ['type' => $props['choice'] ])) }}
@else
    @include('label.index')
    <div class="ulz-notice ulz-notice-alert">
        {{ $props['error_message'] }}
    </div>
@endif
