@include('label.index')

@if( ! empty( $split['available'] ) || ! empty( $split['active'] ) )
    <div class="ulz-order-list ulz-no-select">
        <div class="ulz-grid ulz-no-gutter">
            <div class="ulz-col-6">
                <div class="ulz-list-options ulz-flex ulz-flex-column">
                    <p>{{ $strings->available }}:</p>
                    <ul class="" data-state="disabled">
                        @foreach( $split['available'] as $option_id => $option_name )@include('order-list.item', [
                            'id' => $id,
                            'option_id' => $option_id,
                            'option_name' => $option_name,
                            'disabled' => true
                        ])@endforeach
                    </ul>
                </div>
            </div>
            <div class="ulz-col-6">
                <div class="ulz-order-sort ulz-list-values ulz-flex ulz-flex-column">
                    <p>{{ $strings->active }}:</p>
                    <ul class="" data-state="active">
                        @foreach( $split['active'] as $option_id => $option_name )@include('order-list.item', [
                            'id' => $id,
                            'option_id' => $option_id,
                            'option_name' => $option_name,
                            'disabled' => false
                        ])</li>@endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
@else
    <div class="ulz-notice ulz-notice-alert">
        <p>{{ $repeater_empty_notify }}</p>
    </div>
@endif

{{-- fix for empty inputs in post --}}
<input type="hidden" name="{{ $id }}" disabled="disabled">
