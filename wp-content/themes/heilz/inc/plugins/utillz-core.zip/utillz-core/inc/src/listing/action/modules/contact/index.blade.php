<div class="ulz-mod-action ulz-mod-action-{{ $type }}" data-type="{{ $type }}">
    <div class="ulz-action-contact">

        @if( $enable_author )
            {{ Ucore()->the_template('single/action/author') }}
        @endif

        <div class="ulz-action-footer">
            <div class="ulz--action">
                <a href="#" class="ulz-button ulz--large" data-modal="{{ is_user_logged_in() ? 'conversation' : 'signin' }}" data-params='{"id":{{ $listing_id }}}'>
                    <span>{{ $strings->send_message }}</span>
                </a>
            </div>
        </div>

    </div>
</div>
