<div class="ulz-step-publish ulz-text-center">
    <div>
        <span class="ulz--icon"><i class="fas fa-check"></i></span>
        <h4 class="ulz--title">{{ $strings->success }}</h4>
        @if( $requires_admin_approval )
            <p>{{ $strings->awaits_approval }}</p>
        @else
            <p>{{ $strings->published }}</p>
        @endif
    </div>
</div>
