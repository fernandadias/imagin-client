<?php

use \UtillzCore\Inc\Utils;

/*
 * register utilities
 *
 */
if( ! function_exists('utillz_core') ) {
    function utillz_core() {
        return Utils\Register::instance();
    }
}

if( ! function_exists('Ucore') ) {
    function Ucore() {
    	return utillz_core()->helper();
    }
    utillz_core()->register( 'helper', Utils\Helper::instance() );
    utillz_core()->register( 'icon', Utils\Icon::instance() );
    utillz_core()->register( 'notify', Utils\Notify::instance() );
}
