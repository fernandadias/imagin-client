@include('label.index')

<div class="ulz-opts">
    <div class="ulz-opts-list">
        <ul class="ulz-opts-items">
            @if( is_array( $options ) )
                @foreach( $options as $option_value => $option_name )
                    <li><input type="text" value="{{ is_array( $option_name ) ? $option_name['label'] : $option_name }}" disabled></li>
                @endforeach
            @endif
        </ul>
        <a href="#" class="ulz-button ulz-button-opts-add">
            <span>{{ $strings->add_options }}</span>
        </a>
    </div>
    <div class="ulz-opts-add">
        <p>{!! $options_description !!}</p>
        <textarea
            type="text"
            name="{{ $id }}"
            placeholder="{{ $placeholder }}"
            {{ $v_model ? "v-model={$v_model}" : '' }}>{{ $value_raw }}</textarea>
        <a href="#" class="ulz-button ulz-button-opts-save">
            <span>{{ $strings->save_options }}</span>
        </a>
    </div>
</div>
