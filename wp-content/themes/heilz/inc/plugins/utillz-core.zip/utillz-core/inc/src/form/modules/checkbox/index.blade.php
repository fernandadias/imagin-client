@include('label.index')

<label class='ulz-checkbox ulz-no-select'>
    <input type='checkbox' value="1" {{ $value ? 'checked' : '' }} {{ $v_model ? "v-model={$v_model}" : '' }} {{ $disabled ? 'disabled' : '' }}>
    <span class='ulz--toggle ulz-transition'></span>
    <span class="ulz--text ulz--collect">{{ $html->text }}</span>
</label>

{{-- fix for empty inputs in post --}}
<input type='hidden' name="{{ $id }}" value="{{ $value }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>
