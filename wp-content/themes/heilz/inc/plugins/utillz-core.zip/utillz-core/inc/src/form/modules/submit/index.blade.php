<div class="">
    <input class="ulz-button {{ $button->class }}" {!! $button->id !!} type="submit" value="{{ $name }}">
</div>
