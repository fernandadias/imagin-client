<div class="ulz-field-terms">
    <div class="ulz-terms-taxonomy">
        @php

            $component->render([
                'type' => 'use_field',
                'id' => null,
                'name' => $props['name'],
                'value' => isset( $term_values->taxonomy ) ? $term_values->taxonomy : $props['value'],
                'group' => 'taxonomy',
                'is_wrapped' => false,
            ]);

        @endphp
    </div>
    <div class="ulz-terms-terms @if( $terms ) ulz-active @endif">
        @php

            $default = $props['multiple'] ? [] : '';

            $component->render([
                'type' => 'select',
                'id' => null,
                'name' => esc_html__('Select Terms', 'utillz-core'),
                'value' => isset( $term_values->term ) ? $term_values->term : $default,
                'options' => $terms,
                'is_wrapped' => false,
            ]);

        @endphp
    </div>
    <input type="text" class="ulz-terms-input ulz-none" name="{{ $props['id'] }}" value="{{ is_object( $props['value'] ) ? json_encode( $props['value'] ) : $props['value'] }}">
</div>
