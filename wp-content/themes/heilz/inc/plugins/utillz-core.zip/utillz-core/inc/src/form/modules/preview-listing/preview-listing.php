<?php

namespace UtillzCore\Inc\Src\Form\Modules\Preview_Listing;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Preview_Listing extends Module {

    public function controller() {

        return array_merge( (array) $this->props, [
            'component' => $this->component,
            'props' => [
                'cover' => Ucore()->get('ulz_listing_cover_type', null, true, 'image'),
                'style' => Ucore()->get('ulz_listing_cover_style', null, true, 'landscape'),
                'hide_listing_details' => Ucore()->get('ulz_hide_listing_details'),
                'favorite' => Ucore()->get('ulz_display_listing_favorite', null, true, true),
                'review' => Ucore()->get('ulz_display_listing_review', null, true, true),
                'title' => Ucore()->get('ulz_display_listing_title'),
                'tagline' => Ucore()->get('ulz_display_listing_tagline'),
                'bottom_labels' => Ucore()->get('ulz_display_listing_bottom'),
                'content' => Ucore()->get('ulz_display_listing_content'),
            ],
            'strings' => (object) [
                'preview' => esc_html__( 'Preview', 'utillz-core' ),
                'save' => esc_html__( 'Save changes', 'utillz-core' ),
            ],
        ]);

    }

}
