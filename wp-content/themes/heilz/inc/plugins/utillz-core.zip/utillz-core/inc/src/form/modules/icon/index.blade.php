@include('label.index')

<div class="ulz-icon">

    <div class="ulz--toggle" data-action="icon">
        <div class="ulz--preview">{!! utillz_core()->icon->get( $icon, $set ) !!}</div>
        <div class="ulz--label">{{ $strings->select }}</div>
    </div>

    <div class="ulz--cancel">
        <i class="material-icons" data-action="cancel">cancel</i>
    </div>

    <input type="hidden" name="{{ $id }}" class="ulz--input" value="{{ $value }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>
    <input type="hidden" name="{{ $id }}__set" class="ulz--input-set" value="{{ $set }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>
    <input type="hidden" name="{{ $id }}__icon" class="ulz--input-icon" value="{{ $icon }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>

</div>
