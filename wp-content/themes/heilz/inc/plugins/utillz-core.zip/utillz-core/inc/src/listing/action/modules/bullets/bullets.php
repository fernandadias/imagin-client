<?php

namespace UtillzCore\Inc\Src\Listing\Action\Modules\Bullets;

use \UtillzCore\Inc\Src\Listing\Action\Modules\Module;

class Bullets extends Module {

    // ..

}
