<?php

namespace UtillzCore\Inc\Src\Listing\Modules\Reviews;

use \UtillzCore\Inc\Src\Listing\Modules\Module;

class Reviews extends Module {

    // ..

}
