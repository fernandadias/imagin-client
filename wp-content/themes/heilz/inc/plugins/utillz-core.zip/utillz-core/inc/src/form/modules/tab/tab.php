<?php

namespace UtillzCore\Inc\Src\Form\Modules\Tab;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Tab extends Module {

    // ..

}
