@if( ! empty( $content ) )
    <div class="ulz-mod-listing ulz-mod-listing-content" data-type="content">
        @if( ! empty( $name ) )
            <h4>{{ $name }}</h4>
        @endif
        {!! do_shortcode( wpautop( $content ) ) !!}
    </div>
@endif
