<div class="ulz-mod-action ulz-mod-action-{{ $type }}" data-type="{{ $type }}">
    <div class="ulz-action-application">

        @if( $enable_author )
            {{ Ucore()->the_template('single/action/author') }}
        @endif

        <div class="ulz-action-footer">
            <div class="ulz--action">
                <a href="#" class="ulz-button ulz-button-accent ulz--large" data-modal="{{ is_user_logged_in() ? 'action-application' : 'signin' }}" data-params='{{ $listing_id }}'>
                    <span>
                        {{ $application_button_label ? $application_button_label : $strings->button_label }}
                    </span>
                </a>
            </div>
        </div>

    </div>
</div>
