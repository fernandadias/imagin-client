<?php

namespace UtillzCore\Inc\Utils;

use \UtillzCore\Inc\Src\Woocommerce\Account\Account;

class Woocommerce {

    use \UtillzCore\Inc\Src\Traits\Singleton;

    public $account;

    function __construct() {

        $this->account = Account::instance();

    }

    public function add_account_page( $page ) {
		$this->account->add_page( $page );
	}

}
