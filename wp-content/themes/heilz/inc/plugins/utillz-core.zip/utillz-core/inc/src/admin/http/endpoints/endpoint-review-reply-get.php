<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

use \UtillzCore\Inc\Src\Request\Request;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Review_Reply_Get extends Endpoint {

	public $action = 'utillz-review-reply-get';

    public function action() {

		$request = Request::instance();

		if( ! $request->has('comment_id') ) {
			return;
		}

		wp_send_json([
			'success' => true,
			'html' => Ucore()->get_template('single/reviews/form-reply')
		]);

	}

}
