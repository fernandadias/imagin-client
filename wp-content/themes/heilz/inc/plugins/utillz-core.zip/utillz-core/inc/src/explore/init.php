<?php

namespace UtillzCore\Inc\Src\Explore;

use \UtillzCore\Inc\Extensions\Component\Init as Main_Init;
use \UtillzCore\Inc\Src\Traits\Singleton;

class Init extends Main_Init {

    use Singleton;

    public function enqueue_scripts() {

        wp_enqueue_script('utillz-explore');
        wp_enqueue_style('utillz-explore');

    }

}
