@include('label.index')

@php

$form = new \UtillzCore\Inc\Src\Form\Component();

@endphp

<div class="ulz-filter-tab">
    <div class="ulz-tab-title ulz-no-select" data-label="{{ $label }}">
        <span>{{ $label }}</span>
    </div>
    <div class="ulz-tab-flyout">
        <div class="ulz-tab-content ulz-scrollbar">
            <div class="ulz-grid">
                @php
                    foreach( $fields as $field_id => $field_props ) {
                        $form->render( array_merge( $field_props, [
                            'id' => $field_id
                        ]));
                    }
                @endphp
            </div>
        </div>
        <div class="ulz-tab-footer">
            <div>
                <a href="#" class="ulz-button ulz-small">
                    <span>{{ $strings->close }}</span>
                    {{ Ucore()->preloader() }}
                </a>
            </div>
        </div>
    </div>
</div>

{{-- {{ $form->render( array_merge( $props_default, $props ) ) }} --}}

{{-- <div class="ulz-repeater-item {{ $is_item_hidden ? 'ulz-item-hidden' : '' }} {{ $is_item_empty ? 'ulz-item-empty' : '' }}" data-id="{{ $template->id }}" data-name="{{ $schema['name'] }}" data-heading="{{ isset( $schema['heading'] ) ? $schema['heading'] : '' }}">

    <div class="ulz-item-row ulz-no-select">
        <div class="ulz-item-label">
            <a href="#" class="ulz-item-expand">
                <i class="fas fa-angle-down"></i>
            </a>
            <em class="ulz-item-name">
                {{ $template->name }}
            </em>
            <span class="ulz-item-title">
                {{ isset( $template->heading_text ) ? strip_tags( $template->heading_text ) : '' }}
            </span>
        </div>
        <div class="ulz-item-actions">
            @if( $can_hide )
                <a href="#" class="ulz-item-hide">
                    <i class="fas fa-ban"></i>
                </a>
            @endif
            <a href="#" class="ulz-item-clone">
                <i class="far fa-clone"></i>
            </a>
            <a href="#" class="ulz-item-remove">
                <i class="far fa-trash-alt"></i>
            </a>
        </div>
    </div>

    <div class="ulz-repeater-content ulz-grid">
        @if( is_array( $schema['fields'] ) )
            @foreach( $schema['fields'] as $id => $props_default )
                @php

                    $props = [
                        'id' => $id,
                        'readonly' => true,
                    ];

                    if( isset( $parent ) ) {
                        $props['parent'] = $parent;
                    }

                    if( isset( $fields->{$id} ) ) {
                        $props['value'] = $fields->{$id};
                    }

                    if( isset( $props['value'] ) && is_string( $props['value'] ) ) {
                        $props['value'] = html_entity_decode( $props['value'] );
                    }

                    $form->render( array_merge( $props_default, $props ) );

                @endphp
            @endforeach
        @endif
    </div>

</div> --}}
