<div class="ulz-tab">
    <span class="ulz--name">{{ $name }}</span>
</div>
