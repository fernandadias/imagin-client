@php
    $component->render( array_merge( $props, [
        'type' => 'select',
    ]));
@endphp
