<?php

namespace UtillzCore\Inc\Src\Submission;

use \UtillzCore\Inc\Extensions\Component\Init as Main_Init;
use \UtillzCore\Inc\Src\Traits\Singleton;

class Init extends Main_Init {

    use Singleton;

    function __construct() {

        global $ulz_submission;

        parent::__construct();

        if( ! wp_doing_ajax() ) {
            delete_transient( 'ulz_steps' );
        }

        $ulz_submission = new Submission();

    }

    public function enqueue_scripts() {

        wp_enqueue_script('utillz-submission');
        wp_enqueue_style('utillz-submission');

    }

}
