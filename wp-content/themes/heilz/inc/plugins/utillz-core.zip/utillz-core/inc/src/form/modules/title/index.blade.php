<div class="ulz-just-title">
    <{{ $tag }} class="ulz-the-title">{{ $name }}</{{ $tag }}>
    @if( $description )
        <p>{{ $description }}</p>
    @endif
</div>
