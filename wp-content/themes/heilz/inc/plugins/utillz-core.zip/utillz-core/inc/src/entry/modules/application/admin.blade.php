@if( $action_application )
<div class="ulz-form">
    <div class="ulz-grid">
        @php

            foreach( $action_application->fields->form as $item ) {

                if( $item->fields->show_if_guest && is_user_logged_in() ) {
                    continue;
                }

                $field = $form->create( Ucore()->prefix_item( $item ) );

                if( ! Ucore()->is_error( $field ) ) {
                    echo $field->get();
                }else{
                    echo $field->get_error();
                }

            }

        @endphp
    </div>
</div>
@else
    <p class="ulz-text-center ulz-weight-600 ulz-mb-0">{{ $strings->action_type_not_found }}</p>
@endif
