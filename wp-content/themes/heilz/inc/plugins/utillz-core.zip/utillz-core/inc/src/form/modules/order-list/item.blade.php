<li class="ulz-flex ulz-align-center">
    <div class="ulz-list-drag">
        <i class="fas fa-arrows-alt"></i>
    </div>
    <div class="ulz-list-name">
        {{ $option_name }}
        <input type="hidden" name="{{ $id }}[]" value="{{ $option_id }}" @if( $disabled ) disabled="disabled" @endif>
    </div>
</li>