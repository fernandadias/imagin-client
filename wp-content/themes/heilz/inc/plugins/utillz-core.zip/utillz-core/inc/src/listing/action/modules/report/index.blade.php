<div class="ulz-mod-action ulz-mod-action-{{ $type }}" data-type="{{ $type }}">
    <div class="ulz-action-report">
        <div class="ulz--report ulz-text-center">
            <a href="#" class="ulz--label" data-modal="<?php echo is_user_logged_in() ? 'action-report' : 'signin'; ?>">
                <i class="material-icons ulz-mr-1">error</i>
                {{ $strings->report }}
            </a>
        </div>
    </div>
</div>
