<?php

namespace UtillzCore\Inc\Src\Form\Modules\Auto_Key;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Auto_Key extends Module {

    public function before_construct() {
        $this->defaults += [
            'char_type' => 'any',
            'char_length' => 30,
        ];
    }

}
