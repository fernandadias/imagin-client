<?php

namespace UtillzCore\Inc\Src\Woocommerce;

use \UtillzCore\Inc\Src\Traits\Singleton;

class Checkout {

    use Singleton;

    function __construct() {

        add_action( 'woocommerce_after_checkout_validation', [ $this, 'after_checkout_validation' ], 10, 2 );

    }

    public function after_checkout_validation( $data, $errors ) {

        global $woocommerce;
        $items = $woocommerce->cart->get_cart();

        foreach( $items as $item ) {

            // $product = wc_get_product( $item['product_id'] );
            // make any checks here ..
            // $errors->add( 'validation', esc_html__( 'Some error handler', 'utillz-core' ) );

        }
	}

}
