<?php

namespace UtillzCore\Inc;

use \UtillzCore\Inc\Src\Traits\Singleton;

class Init {

    use Singleton;

    function __construct() {

        Src\Setup::instance();
        Src\Forgery::instance();
        Src\Admin::instance();
        Src\Assets::instance();
        Src\Install::instance();
        Src\Schedule::instance();
        Src\Icon_Sets::instance();
        Src\Shortcodes::instance();
        Src\Taxonomies::instance();
        Src\Post_Types::instance();
        Src\Widgets::instance();
        Src\Woocommerce\Init::instance();

    }

}
