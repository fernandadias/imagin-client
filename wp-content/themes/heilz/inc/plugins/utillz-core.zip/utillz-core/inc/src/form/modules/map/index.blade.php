@include('label.index')

<div class="ulz-location">
    <div class="ulz-grid">

        <div class="ulz-form-group ulz-col-12 ulz-col-md-12 ulz-mb-4">
            <label class="ulz-block ulz-mb-2">{{ $strings->address }}</label>
            <input type="text" class="ulz-map-address" name="{{ $id }}[]" value="{{ $value[0] }}" placeholder="{{ $strings->e_g_city }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>
        </div>
        <div class="ulz-form-group ulz-col-6 ulz-col-md-12 ulz-mb-4 ulz-none">
            <label class="ulz-block ulz-mb-2">{{ $strings->latitude }}</label>
            <input type="text" value="{{ $value[1] }}" disabled>
                <input type="hidden" class="ulz-map-lat" name="{{ $id }}[]" value="{{ $value[1] }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>
        </div>
        <div class="ulz-form-group ulz-col-6 ulz-col-md-12 ulz-mb-4 ulz-none">
            <label class="ulz-block ulz-mb-2">{{ $strings->longitude }}</label>
            <input type="text" value="{{ $value[2] }}" disabled>
                <input type="hidden" class="ulz-map-lng" name="{{ $id }}[]" value="{{ $value[2] }}" {{ $readonly ? 'form="fake-form-readonly"' : '' }}>
        </div>

        <!-- geo information -->
        <div class="ulz-none">
            <input type="text" class="ulz-map-country" name="{{ $id }}[]" value="{{ isset( $value[3] ) ? $value[3] : '' }}">
            <input type="text" class="ulz-map-city" name="{{ $id }}[]" value="{{ isset( $value[4] ) ? $value[4] : '' }}">
            <input type="text" class="ulz-map-city-alt" name="{{ $id }}[]" value="{{ isset( $value[5] ) ? $value[5] : '' }}">
        </div>

    </div>
    <div class="ulz-map">
        @if( ! $api_key )
            <span class="ulz-none">{{ $strings->no_api }}</span>
        @endif
    </div>
</div>
