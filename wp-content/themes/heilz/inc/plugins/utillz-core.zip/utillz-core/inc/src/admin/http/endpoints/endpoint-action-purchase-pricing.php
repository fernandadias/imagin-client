<?php

namespace UtillzCore\Inc\Src\Admin\Http\Endpoints;

use \UtillzCore\Inc\Src\Request\Request;
use \UtillzCore\Inc\Src\Validation;
use \UtillzCore\Inc\Src\Listing\Listing;
use \UtillzCore\Inc\Src\Form\Component as Form;

if ( ! defined('ABSPATH') ) {
	exit;
}

class Endpoint_Action_Purchase_Pricing extends Endpoint {

	public $action = 'utillz-action-purchase-pricing';

    public function action() {

		$request = Request::instance();

		if( ! $request->is_empty('listing_id') ) {

			$listing = new Listing( $request->get('listing_id') );

			if( $listing->id ) {

				wp_send_json([
					'success' => true,
					'html' => Ucore()->get_template('single/pricing-purchase')
				]);

			}

		}

		wp_send_json([
			'success' => false
		]);

		wp_send_json( $response );

	}

}
