<?php

namespace UtillzCore\Inc\Src\Form\Modules\Hidden;

use \UtillzCore\Inc\Src\Form\Modules\Module;

class Hidden extends Module {

    // ..

}
