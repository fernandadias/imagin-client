'use strict'

// import label from './label'

window.$ = window.jQuery

export default class base {

    constructor( field ) {

        this.$ = field

    }

    start() {

        this.init()
        this.$.addClass('ulz-field-ready')
        window.utillz_core_vars.is_admin ? this.init_admin() : this.init_front()

    }

    init() {}
    init_admin() {}
    init_front() {}

    // collect field data
    collect() {

        $(document).trigger('utillz:form/changed')
        $(document).trigger('utillz:form/labels')

        this.$.trigger('utillz:form/field/changed')

    }

    get_label() {
        return null
    }

    ajaxing() {

        if( this.$.hasClass('ulz-ajaxing') ) {
            return
        }
		this.$.addClass('ulz-ajaxing')

    }

}
