'use strict'

window.$ = window.jQuery
window.Utillz_Core = window.Utillz_Core || {}

class Utillz_Core_Mobile {

	constructor() {

		$(document).ready(() => this.ready())

	}

	ready() {

		this.$b = $('body')

		this.init()

	}

	init() {

		this.bind()

	}

	bind() {

		$(document).on('click', `[data-action='toggle-search-filters']`, e => this.toggle_search_filters(e))

	}

	toggle_search_filters(e) {

		let $e = $( e.currentTarget )
		this.$b.toggleClass('ulz--expand-search-filters')

	}

}

export default new Utillz_Core_Mobile()
