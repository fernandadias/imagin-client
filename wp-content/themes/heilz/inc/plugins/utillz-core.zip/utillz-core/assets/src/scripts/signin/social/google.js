'use strict'

import debug from '../../utils/debug'

window.$ = window.jQuery

export default class Google {

    constructor() {

        debug.log('site', 'Signin: social - Google')

        this.init()

	}

	init() {

        this.$button = $(`[data-action='sign-in-google']`)

	}

    gapis_init() {

        gapi.load('auth2', () => {

            if( this.$button.length ) {

                let auth2 = gapi.auth2.init({
                    client_id: window.utillz_core_vars.sdk.google.client_id,
                    cookiepolicy: 'single_host_origin',
                    scope: 'profile email'
                })

                auth2.attachClickHandler( this.$button.get(0), {},
                    ( googleUser ) => {

                        let profile = googleUser.getBasicProfile()

                        $.ajax({
                            type: 'post',
                            dataType: 'json',
                            url: window.utillz_core_vars.admin_ajax,
                            data: {
                                action: 'utillz-signin-google',
                                id: profile.getId(),
                                name: profile.getName(),
                                first_name: profile.getGivenName(),
                                last_name: profile.getFamilyName(),
                                email: profile.getEmail(),
                                picture: profile.getImageUrl(),
                                security: window.utillz_core_vars.nonce,
                                role: $('[name="role"]').val()
                            },
                			beforeSend: () => {
                				this.$button.addClass('ulz-ajaxing')
                			},
                			complete: () => {

                            },
                			success: ( response ) => {

                				if( response.success ) {

                                    window.location.reload()

                                }else{

                                    this.$button.removeClass('ulz-ajaxing')

                                }

                			}
                        })

                    },
                    ( error ) => {
                        console.log( 'Sign-in error', error )
                    }
                );

            }

        })

    }

    request() {

    }

}
