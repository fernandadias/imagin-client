'use strict'

window.$ = window.jQuery

export default class base {

    constructor( data ) {

        // data
        this.data = data
        this.e = data.event
        this.params = data.params
        this.type = data.type

        // elements
        this.$ = data.element
        this.$body = $('body')
        this.$append = $('.ulz-modal-append', this.$)

        this.visibility()

    }

    visibility() {
        this.$.addClass('ulz-visible')
        this.$body.addClass(`ulz-modal-open ulz-modal-open--${this.data.id}`)
    }

    init() {}
    close() {}

    ajaxing() {

        if( this.$.hasClass('ulz-ajaxing') ) {
            return
        }
		this.$.addClass('ulz-ajaxing')
        this.$append.html('')

    }
}
