export default () => {

    if( window.utillz_core_vars.map.style == 'custom' ) {
        let style_custom = window.utillz_core_vars.map.style_custom
        if( typeof style_custom == 'object' ) {
            return style_custom
        }
    }else{
        try{
            return require( `./styles/${window.utillz_core_vars.map.style || 'default'}` ).default
        }catch( ex ) {
            console.log('Error: map style does not exist!')
        }
    }

    return []

}
